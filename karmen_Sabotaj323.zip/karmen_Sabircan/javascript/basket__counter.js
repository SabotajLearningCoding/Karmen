// Hent de nødvendige elementer
const plusButton = document.querySelector(".shop__plus");
const minusButton = document.querySelector(".shop__minus");
const counterElement = document.querySelector(".shop__counter");
const priceElement = document.querySelector(".shop__price");

// Initialiser pris- og tæller-variablerne
let price = 50;
let counter = 1;

// Funktion til at opdatere prisen og vise den
function opdaterPris() {
  priceElement.textContent = price + " Kr";
}

// Funktion til at opdatere tælleren og vise den
function opdaterTæller() {
  counterElement.textContent = counter;
}

// Eventlytter til plus-knappen
plusButton.addEventListener("click", function () {
  price += 50;
  counter++;
  opdaterPris();
  opdaterTæller();
});

// Eventlytter til minus-knappen
minusButton.addEventListener("click", function () {
  if (counter > 1) {
    price -= 50;
    counter--;
    opdaterPris();
    opdaterTæller();
  }
});

// Opdater den indledende pris og tæller
opdaterPris();
opdaterTæller();
