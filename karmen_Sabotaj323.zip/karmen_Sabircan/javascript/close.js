// Hent de nødvendige elementer
const closeButton = document.querySelector(".shop__close");
const articleElement = document.querySelector(".shop__article");

// Funktion til at skjule artiklen
function skjulArtikel() {
  articleElement.style.display = "none";
}

// Eventlytter til luk-knappen
closeButton.addEventListener("click", function (event) {
  event.preventDefault(); // Forhindrer standardadfærd for linket
  skjulArtikel();
});
