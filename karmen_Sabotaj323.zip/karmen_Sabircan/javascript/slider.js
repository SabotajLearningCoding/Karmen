let index = 1; // Vi opretter en variabel med navnet "index" og giver den værdien 1. Dette er tælleren, der holder styr på det aktuelle billede.

const bigImg = document.querySelector(".product__img"); // Vi finder det element på siden, der har klassen "product__img" og gemmer det i variablen "bigImg". Dette er det store billede, der vises.

const leftArrow = document.querySelector(".product__arrowLeft"); // Vi finder elementet på siden, der har klassen "product__arrowLeft" og gemmer det i variablen "leftArrow". Dette er pilen, der peger mod venstre.
const rightArrow = document.querySelector(".product__arrowRight"); // Vi finder elementet på siden, der har klassen "product__arrowRight" og gemmer det i variablen "rightArrow". Dette er pilen, der peger mod højre.

leftArrow.addEventListener("click", showPrev); // Vi tilføjer en lytter til klik-hændelsen på venstre pil. Når der klikkes på pilen, skal funktionen "showPrev" udføres, hvilket viser det forrige billede.
rightArrow.addEventListener("click", showNext); // Vi tilføjer en lytter til klik-hændelsen på højre pil. Når der klikkes på pilen, skal funktionen "showNext" udføres, hvilket viser det næste billede.

function showNext() {
  if (index < 3) {
    index++; // Hvis værdien af "index" er mindre end 3, øges den med 1 for at gå til det næste billede.
  } else {
    index = 1; // Hvis værdien af "index" er 3 eller større, sættes den til 1 for at gå tilbage til det første billede.
  }
  let newSrc = "../images/slider/sukkulent" + index + ".png"; // Vi sammensætter en sti til det næste billede baseret på værdien af "index".
  console.log(newSrc); // Vi viser stien til det næste billede i konsollen.
  bigImg.setAttribute("src", newSrc); // Vi opdaterer kilden til det store billede, så det viser det nye billede.

  // Fjern den aktive klasse fra alle prikkerne
  const dots = document.querySelectorAll(".product__dot"); // Vi finder alle elementer på siden, der har klassen "product__dot" og gemmer dem i variablen "dots".
  dots.forEach(dot => {
    dot.classList.remove("active"); // For hvert element fjerner vi klassen "active", hvis den er til stede. Dette skjuler alle prikker.
  });

  // Tilføj den aktive klasse til den aktuelle prik
  const currentDot = document.querySelector(".product__dot:nth-child(" + index + ")"); // Vi finder den prik, der svarer til det aktuelle billede ved hjælp af værdien af "index".
  currentDot.classList.add("active"); // Vi tilføjer klassen "active" til den prik, så den bliver synlig og markeret som aktiv.
}

function showPrev() {
  if (index > 1) {
    index--; // Hvis værdien af "index" er større end 1, reduceres den med 1 for at gå til det forrige billede.
  } else {
    index = 3; // Hvis værdien af "index" er 1 eller mindre, sættes den til 3 for at gå til det sidste billede.
  }
  let newSrc = "../images/slider/sukkulent" + index + ".png"; // Vi sammensætter en sti til det forrige billede baseret på værdien af "index".
  console.log(newSrc); // Vi viser stien til det forrige billede i konsollen.
  bigImg.setAttribute("src", newSrc); // Vi opdaterer kilden til det store billede, så det viser det nye billede.

  // Fjern den aktive klasse fra alle prikkerne
  const dots = document.querySelectorAll(".product__dot"); // Vi finder alle elementer på siden, der har klassen "product__dot" og gemmer dem i variablen "dots".
  dots.forEach(dot => {
    dot.classList.remove("active"); // For hvert element fjerner vi klassen "active", hvis den er til stede. Dette skjuler alle prikker.
  });

  // Tilføj den aktive klasse til den aktuelle prik
  const currentDot = document.querySelector(".product__dot:nth-child(" + index + ")"); // Vi finder den prik, der svarer til det aktuelle billede ved hjælp af værdien af "index".
  currentDot.classList.add("active"); // Vi tilføjer klassen "active" til den prik, så den bliver synlig og markeret som aktiv.
}
