let index = 1; // Vi starter med at tælle fra tallet 1.

const bigImg = document.querySelector(".product__img"); // Vi finder det store billede på siden.

const leftArrow = document.querySelector(".product__arrowLeft"); // Vi finder pilen, der peger mod venstre.
const rightArrow = document.querySelector(".product__arrowRight"); // Vi finder pilen, der peger mod højre.

leftArrow.addEventListener("click", showPrev); // Når vi trykker på pilen mod venstre, skal vi vise det forrige billede.
rightArrow.addEventListener("click", showNext); // Når vi trykker på pilen mod højre, skal vi vise det næste billede.

function showNext() {
  if (index < 3) { // Hvis vi ikke er nået til det tredje billede endnu,
    index++; // tæller vi op med 1 for at vise det næste billede.
  } else { 
    index = 1; // Hvis vi allerede er ved det tredje billede, går vi tilbage til det første billede.
  }

  let newSrc = "../images/slider/sukkulent" + index + ".png"; // Vi sammensætter en sti til det næste billede.
  console.log(newSrc); // Vi viser stien til det næste billede i konsollen.
  bigImg.setAttribute("src", newSrc); // Vi opdaterer det store billede med det nye billede.
}

function showPrev() {
  if (index > 1) { // Hvis vi ikke er ved det første billede,
    index--; // tæller vi ned med 1 for at vise det forrige billede.
  } else {
    index = 3; // Hvis vi allerede er ved det første billede, går vi til det tredje billede.
  }
  let newSrc = "../images/slider/sukkulent" + index + ".png"; // Vi sammensætter en sti til det forrige billede.
  console.log(newSrc); // Vi viser stien til det forrige billede i konsollen.
  bigImg.setAttribute("src", newSrc); // Vi opdaterer det store billede med det nye billede.
}

function begynd() {
  let index = 1; // Vi starter med at tælle fra tallet 1.
  console.log(index); // Vi viser tallet 1 i konsollen.
}
console.log(index); // Vi viser tallet 1 i konsollen.
begynd(); // Vi starter tællingen fra tallet 1.

